<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en"><head><script src="//archive.org/includes/analytics.js?v=cf34f82" type="text/javascript"></script>
<script type="text/javascript">window.addEventListener('DOMContentLoaded',function(){var v=archive_analytics.values;v.service='wb';v.server_name='wwwb-app31.us.archive.org';v.server_ms=577;archive_analytics.send_pageview({});});</script><script type="text/javascript" src="/_static/js/ait-client-rewrite.js" charset="utf-8"></script>
<script type="text/javascript">
WB_wombat_Init("https://web.archive.org/web", "20080113114749", "www.msn.com:80");
</script>
<script type="text/javascript" src="/_static/js/wbhack.js" charset="utf-8"></script>
<script type="text/javascript">
__wbhack.init('https://web.archive.org/web');
</script>
<link rel="stylesheet" type="text/css" href="/_static/css/banner-styles.css">
<link rel="stylesheet" type="text/css" href="/_static/css/iconochive.css">
<!-- End Wayback Rewrite JS Include -->

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>We're sorry, the page you requested could not be found</title>
		<link href="https://web.archive.org/web/20080113114749cs_/http://sc.msn.com/c/my/404err.css" type="text/css" rel="stylesheet"></head>
	<body class="container">







		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<div class="container" id="head">
			<img src="https://web.archive.org/web/20080113114749im_/http://c.msn.com/c.gif?DI=5609&amp;TP=http://errorpages.msn.com/US404" style="width:1px; height:1px; display:none" alt="">
			<div id="big6">
				<ul>
					<li class="first">
						<a href="https://2009msn.neocities.org">MSN Home</a></li>
					<li>
						<a href="https://web.archive.org/web/20080113114749/http://my.msn.com/">My MSN</a></li>
					<li>
						<a href="https://outlook.com">Hotmail</a></li>
					<li>
						<a href="https://web.archive.org/web/20080113114749/http://shopping.msn.com/">Shopping</a></li>
					<li>
						<a href="https://web.archive.org/web/20080113114749/http://moneycentral.msn.com/home.asp">Money</a></li>
					<li>
						<a href="https://web.archive.org/web/20080113114749/http://groups.msn.com/people.msw">People &amp; Chat</a></li>
				</ul>
			</div>
			<div id="image">
				<h1><a id="MSNHeader_MSNLogoLink" href="https://web.archive.org/web/20080113114749/http://www.msn.com/"><img id="MSNHeader_MSNLogo" style="WIDTH: 118px; HEIGHT: 35px" alt="MSN.com" src="https://web.archive.org/web/20080113114749im_/http://sc.msn.com/c/my/msft404logo.gif"></a></h1>
			</div>
		</div>
		<div class="container">
			<div id="left">
				<div><p>&nbsp;</p>
					<p>&nbsp;</p>
					<p>&nbsp;</p>
					<p>&nbsp;</p>
					<p>&nbsp;</p>
					<p class="heading2">The page you have requested cannot be found.</p>
					<br>
					<p>The web page you were attempting to view may not exist or may have moved - try 
						checking the web address for typos.<br>
						<br>
						MSN Search or the site map can help you find what you're looking for.
					</p>
					<p>&nbsp;</p>
				</div>
				<form action="https://search.msn.com/results.aspx" method="get" id="Form1">
					<div><label for="search">Search MSN.com : </label><input class="searchtext" type="text" id="search" name="q" maxlength="150" size="20" value=""><input class="search" type="submit" value="Search" id="Submit4" name="Submit4"><input type="hidden" name="q1" value="site:msn.com" id="Hidden1">
						<br>
						or<span class="error">
							<a href="https://search.msn.com/">Search The Web</a></span></div>
				</form>
			</div>
			<div id="right">
				<div class="heading"><strong>MSN NETWORK SITE MAP</strong></div>
				<div class="sitenav"><h4>News and Sports</h4>
					<a href="https://web.archive.org/web/20080113114749/http://video.msn.com/">MSN Video</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://msnbc.com/">News</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://slate.msn.com/">Slate 
						Magazine</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://msn.foxsports.com/">Sports by FOX 
						Sports</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://weather.msn.com/">Weather</a>
				</div>
				<div class="sitenav"><h4>Look it Up</h4>
					<a href="https://web.archive.org/web/20080113114749/http://local.msn.com/default.asp">City Guides</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://encarta.msn.com/">Encarta</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://mappoint.msn.com/">Maps 
						&amp; Directions</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://www.whitepages.com/5050">White&nbsp; 
						Pages</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://yellowpages.msn.com/">Yellow Pages</a>
				</div>
				<div class="sitenav"><h4>Living &amp; Finances</h4>
					<a href="https://web.archive.org/web/20080113114749/http://careers.msn.com/">Careers &amp; Jobs</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://qspace.iplace.com/cobrands/444/home149.asp?sc=6151HPPP">Credit 
						Report</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://msn.match.com/msn/">Dating &amp; 
						Personals</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://health.msn.com/">Health &amp; 
						Fitness</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://houseandhome.msn.com/">House &amp; 
						Home</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://moneycentral.msn.com/home.asp">Money</a>
				</div>
				<div class="sitenav"><h4>Shop</h4>
					<a href="https://web.archive.org/web/20080113114749/http://shopping.msn.com/softcontent/softcontent.aspx?scmId=978">Auctions</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://autos.msn.com/">Autos</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://houseandhome.msn.com/homes/homesoverview.aspx">Buy 
						a House</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://houseandhome.msn.com/rentals/rentalsoverview.aspx">Rent 
						An Apartment</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://travel.msn.com/">Travel</a>
				</div>
				<div class="sitenav"><h4>Entertainment</h4>
					<a href="https://web.archive.org/web/20080113114749/http://games.msn.com/">Games</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://www.msn.americangreetings.com/index_msn.pd">Greeting&nbsp;Cards</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://astrocenter.astrology.msn.com/msn/">Horoscopes</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://movies.msn.com/">Movies</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://music.msn.com/">Music
					</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://tv.msn.com/">TV</a>
				</div>
				<div class="sitenav"><h4>Technology</h4>
					<a href="https://web.archive.org/web/20080113114749/http://tech.msn.com/downloads/">Downloads</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://www.microsoft.com/">Microsoft.com</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://tech.msn.com/">Tech 
						&amp; Gadgets</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://windowsupdate.microsoft.com/">Windows 
						Update</a>
				</div>
				<div class="sitenav"><h4>People</h4>
					<a href="https://web.archive.org/web/20080113114749/http://family.msn.com/">Family</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://groups.msn.com/">Groups 
						&amp; Chat</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://kids.msn.com/">Kids</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://latino.msn.com/">Latino</a>&nbsp;•&nbsp;<a href="https://web.archive.org/web/20080113114749/http://womencentral.msn.com/">Women</a>
				</div>
			</div>
		</div>
		<div class="gptop">
			<div class="nsft" id="foot">
				<table id="Table1" cellspacing="0" width="750">
					<tbody><tr>
						<td colspan="2"></td>
					</tr>
					<tr>
						<td colspan="2"></td>
					</tr>
					<tr>
						<td><span class="nsf" id="MSNFooter_Terms">©2019 JarHead Software. Page by Microsoft. This is not the Egg.&nbsp;&nbsp;&nbsp;<a href="https://web.archive.org/web/20080113114749/http://privacy.msn.com/tou/">Legal</a>
								&nbsp;&nbsp;<a href="https://web.archive.org/web/20080113114749/http://privacy.msn.com/ ">MSN Privacy</a>
								&nbsp;&nbsp;<a href="https://web.archive.org/web/20080113114749/http://advertising.msn.com/home/home.asp ">Advertise</a>
								&nbsp;&nbsp;</span>
						</td>
						<td align="right"><a id="MSNFooter_lnkFeedback" href="https://web.archive.org/web/20080113114749/http://support.msn.com/feedback.aspx">Feedback</a>&nbsp;&nbsp;
						</td>
					</tr>
				</tbody></table>
			</div>
		</div>
	


</body></html>